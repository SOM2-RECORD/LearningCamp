<template>
    <div class="card">
        <h1>부모 페이지입니다.</h1>
        <div>
            <ChildPage :children="children"/>
        </div>
    </div>
</template>
<script setup>
import { ref } from 'vue'
import ChildPage from '@/components/ChildPage.vue';

const children = ref([
    {name:"김하나", age:30},
    {name:"김두리", age:20},
    {name:"김서이", age:10}
])
</script>

<style>
.card{
    border : 1px solid black;
    padding: 10px;
    margin-bottom : 10px;
}
</style>