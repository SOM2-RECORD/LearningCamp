<template>
  <ParentPage/>
</template>

<script setup>
import ParentPage from "@/components/ParentPage.vue";
</script>