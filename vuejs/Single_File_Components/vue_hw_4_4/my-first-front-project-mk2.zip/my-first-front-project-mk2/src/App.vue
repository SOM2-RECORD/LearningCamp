<template>
  <ColorChange/>
</template>

<script setup>
import ColorChange from '@/components/ColorChange.vue';
</script>