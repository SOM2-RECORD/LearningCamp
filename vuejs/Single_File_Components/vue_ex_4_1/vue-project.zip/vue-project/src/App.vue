<!-- src/App.vue -->
<template>
  <div id="app">
    <MyComponent/>
  </div>
</template>

<script setup>
import MyComponent from './components/MyComponent.vue';

</script>

<style scoped>
</style>