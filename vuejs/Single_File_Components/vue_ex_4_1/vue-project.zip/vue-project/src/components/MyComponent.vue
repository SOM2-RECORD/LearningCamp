<!-- src/components/MyComponent.vue -->
<template>
    <div>
        <header>
            <h1>Gallery</h1>    
        </header>
        <main>
            <img src="@/assets/sample.png"/>
        </main>
    </div>
</template>

<script setup>

</script>

<style scoped>
</style>