<template>
    <div>
        <h1>첫 페이지</h1>
    </div>
</template>

<script setup>
</script>
