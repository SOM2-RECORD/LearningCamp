<template>
    <div>
        <h1>이동한 페이지</h1>
    </div>
</template>

<script setup>
</script>
