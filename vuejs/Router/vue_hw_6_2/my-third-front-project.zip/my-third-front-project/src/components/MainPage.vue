<template>
    <h1>router연습하기</h1>
</template>